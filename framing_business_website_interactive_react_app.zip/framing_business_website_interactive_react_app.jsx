import { useState, useEffect } from "react";

const mouldings = [
  { code: "GL-101", name: "Luxury Gold", price: 1500, img: "/images/gold-01.jpg" },
  { code: "WD-201", name: "Wood Brown", price: 1200, img: "/images/wood-01.jpg" },
  { code: "MD-301", name: "Modern Black", price: 800, img: "/images/black-01.jpg" }
];

const sizes = {
  "8x10": 1,
  "12x16": 1.5,
  "16x20": 2
};

const paperTypes = {
  matte: { name: "Matte", price: 0 },
  glossy: { name: "Glossy", price: 100 },
  canvas: { name: "Canvas", price: 300 }
};

export default function App() {
  const [image, setImage] = useState(null);
  const [frame, setFrame] = useState(mouldings[0]);
  const [size, setSize] = useState("12x16");
  const [paper, setPaper] = useState("matte");
  const [mount, setMount] = useState(false);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem("orders");
    if (saved) setOrders(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("orders", JSON.stringify(orders));
  }, [orders]);

  const base = frame.price * sizes[size];
  const paperCost = paperTypes[paper].price;
  const mountCost = mount ? 200 : 0;
  const total = Math.round(base + paperCost + mountCost);

  const handleOrder = () => {
    const newOrder = {
      name,
      phone,
      address,
      frame: frame.code,
      size,
      paper,
      mount,
      total
    };

    setOrders([...orders, newOrder]);

    alert("Order placed successfully! Payment integration coming next.");
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-3xl font-bold text-center mb-6">RK Photo Frame</h1>

      <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">

        {/* PREVIEW */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Live Preview</h2>

          <div className="bg-gray-200 p-4 rounded-xl">
            <div style={{ border: "20px solid #333" }}>
              {mount ? (
                <div className="bg-white p-4">
                  {image ? (
                    <img src={image} className="w-full h-64 object-cover" />
                  ) : "Upload Image"}
                </div>
              ) : image ? (
                <img src={image} className="w-full h-64 object-cover" />
              ) : "Upload Image"}
            </div>
          </div>
        </div>

        {/* CONTROLS */}
        <div className="bg-white rounded-2xl shadow-lg p-6 space-y-5">
          <h2 className="text-xl font-semibold">Customize</h2>

          <input type="file" onChange={(e) => setImage(URL.createObjectURL(e.target.files[0]))} />

          {/* FRAME */}
          <div>
            <p className="font-semibold">Frame</p>
            <div className="grid grid-cols-3 gap-2">
              {mouldings.map((m) => (
                <div key={m.code} onClick={() => setFrame(m)} className={`border p-2 cursor-pointer ${frame.code === m.code ? "ring-2 ring-black" : ""}`}>
                  <img src={m.img} className="h-16 w-full object-cover" />
                  <p className="text-xs text-center">{m.code}</p>
                </div>
              ))}
            </div>
          </div>

          {/* SIZE */}
          <select value={size} onChange={(e) => setSize(e.target.value)}>
            {Object.keys(sizes).map((s) => <option key={s}>{s}</option>)}
          </select>

          {/* PAPER */}
          <select onChange={(e) => setPaper(e.target.value)}>
            {Object.keys(paperTypes).map((p) => (
              <option key={p}>{paperTypes[p].name}</option>
            ))}
          </select>

          {/* MOUNT */}
          <label>
            <input type="checkbox" onChange={(e) => setMount(e.target.checked)} /> Add Mount
          </label>

          {/* TOTAL */}
          <h2 className="text-xl font-bold">₹ {total}</h2>

          {/* CUSTOMER FORM */}
          <input placeholder="Full Name" value={name} onChange={(e) => setName(e.target.value)} className="border p-2 w-full" />
          <input placeholder="Phone" value={phone} onChange={(e) => setPhone(e.target.value)} className="border p-2 w-full" />
          <textarea placeholder="Address" value={address} onChange={(e) => setAddress(e.target.value)} className="border p-2 w-full" />

          <button onClick={handleOrder} className="bg-black text-white px-4 py-2 rounded w-full">
            Place Order
          </button>
        </div>
      </div>

      {/* ADMIN PANEL */}
      <div className="max-w-4xl mx-auto mt-10">
        <h2 className="text-xl font-bold mb-3">Orders</h2>
        {orders.map((o, i) => (
          <div key={i} className="border p-3 mb-2">
            {o.name} | {o.frame} | ₹{o.total}
          </div>
        ))}
      </div>
    </div>
  );
}
